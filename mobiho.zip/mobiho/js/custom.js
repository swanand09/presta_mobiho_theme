$(function(){
 
	// Text resizer
   	$(".text-sizer a").textresizer({
      target: "body",
      type: "fontSize",
      sizes: [ "14px", "15px", "16px", ],
      selectedIndex: 1
   	});

});